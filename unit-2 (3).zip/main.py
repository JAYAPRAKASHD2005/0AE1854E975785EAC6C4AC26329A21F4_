#Teating the BankAccount class
if_name_="__main__":
#Create a BankAccount instance
account1 =BankAccount("123456","JohnDoe",1000.0)

#Deposit money
account1.deposit(500.0)

#Withdraw money
account1.wiyhdraw(200.0)

#Display balance
account1.display_balance()

def withdraw(self,amount):
if amount>0:
if self.__account_balance>=amount:
  self.__accont_balance-=amount
  print(f"withdrew ${amount:2f}from account{self.__account _number}")
else:
  print("Insufficient balance.Cannot withdraw.")
else:
print("Invalid withdraweal amount.Please withdraw a positive amount.")

def display_balance(self):
print(f"Account{self.__account_number}balance:${self.__account_balance:.2f}")

#Testing the BankAccount class
if_name_=="__main__":
account_number
self.__account_holder_name=account_holder_name
account_holder_name
self.__account_balance=initial_balance

def deposit(self,amount):
  if amount>0:
    self.__account_balance+=amountprint(f"Deposited ${amount:.2f}into account{self.__account_number}")
  else:
  print("Invalid deposit amount.Please deposit a positive amount.")

def withdraw(self,amount):
  if amount>0:
    if self.__account_balance>=amount:
      self.__account_balance-=amountprint(f"Withdrew ${amount:.2f}from account{self.__account_number}")

#2.1 Implement a class called BankAccount that represents a bank account.The class should have private attributes for account number,account holder name,and account balance.Include methods to deposit money,withdraw money,and display the account balance.Ensure that the account balance cannot be accessed directly from outside the class.Write a program to create an instance of the BankAccount class and test the deposit and withdrawal functionality.
class BankAccount:
  def__init__(self,acccount_number,account_holder_name,initial_balance=0.0):
  self.__account_number=account_number
  self.__account_holder_name=account_holder_name
  self__account_balance=initial balance
  #2.2 Implement a class called player that represents a cricket player.THe player class should have a method called play()which prints"The player is playing cricket.Derive two classes,Batsmanand Bowler,from the player class.Override the play()method in each derived class to print"The batsman is batting"and"The bowler is bowling",respectively.Write a program to  create objects of the Batsman and Bowler classes and call the play()method for each object.
  #Define the player class
  class player:
    def play(self):
      print("The player is playing cricket.")
      #Define the Batsman class,derived from player
      class Batsman(player):
        print("The player is playing cricket.")
        #Define the Batsman class,derived from player
        class Batsman(Player):
          def play(self):
            print("The batsman is batting.")
            #Define the Bowler class,derived from player
class Bowler(player):
  def play(self):
    prnt("The bowler is bowling.")
    #Create objects of Batsman and Bowler classes
            batsman=Batsman()
    bowler=Bowler()
    #Call the play() method for each object 
    batsman.play()
    bowler.play()
    